var searchData=
[
  ['_5fxopen_5fsource_0',['_XOPEN_SOURCE',['../part1_2src_2main_8c.html#a78c99ffd76a7bb3c8c74db76207e9ab4',1,'main.c']]]
];
