var searchData=
[
  ['is_5fempty_0',['is_empty',['../part2_2include_2list_8h.html#a4df754b95439918e8813c67771283a40',1,'is_empty(struct list *l):&#160;list.c'],['../part2_2src_2list_8c.html#a4df754b95439918e8813c67771283a40',1,'is_empty(struct list *l):&#160;list.c'],['../part3_2include_2list_8h.html#a4df754b95439918e8813c67771283a40',1,'is_empty(struct list *l):&#160;list.c']]],
  ['is_5flt_5f40_1',['is_lt_40',['../part1_2src_2main_8c.html#a6780db34e9c5479a0725f6a14cfc3be9',1,'main.c']]],
  ['is_5fprime_2',['is_prime',['../part1_2src_2main_8c.html#a2e4a2c3c038b5d5431de664b73a740bb',1,'main.c']]]
];
