var searchData=
[
  ['mem_0',['MEM',['../part1_2src_2main_8c.html#a249f4b957c983020b02c6c6376c47c6a',1,'main.c']]]
];
