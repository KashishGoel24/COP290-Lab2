var searchData=
[
  ['nested_0',['nested',['../part1_2src_2main_8c.html#ad77ac013b3c2f86e8e6a4ea8734e65f1',1,'main.c']]]
];
