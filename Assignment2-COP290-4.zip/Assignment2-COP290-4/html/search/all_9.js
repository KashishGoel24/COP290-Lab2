var searchData=
[
  ['nested_0',['nested',['../part1_2src_2main_8c.html#ad77ac013b3c2f86e8e6a4ea8734e65f1',1,'main.c']]],
  ['next_1',['next',['../structlistentry.html#a9afb253e4f1ccd87a285e84e4ea9609f',1,'listentry']]]
];
