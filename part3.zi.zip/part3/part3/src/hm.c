#include "../include/mythread.h"
#include "../include/list.h"
#include <string.h>
#define SZ 4096

/// @brief This is the data structure to store an element in the hashmap
struct hashmap_element_s {
  char *key;
  void *data;
};

/// @brief This is the data structure to store the hashmap
struct hashmap_s {
  struct list* table[SZ];
  struct lock* lk[SZ];
};

/**
 * @brief This is the funciton that returns the hashfunciton used to compute the index in the hashtable
 * 
 * @param string The key
 * @param len Length of the key
 * @return int The hashfunction
 */
int hashfunction( char string[],int len)
{   if (len == 0)
      {
        return 0;
      }
    else
    return (3023*((int) (string[len-1]))+ hashfunction(string,(len-1)))%4096;// A  completely random hash funciton.
}
/**
 * @brief This function initializes an empty hashtable
 * 
 * @param out_hashmap A pointer to the hashmap that is to be initialized
 * @return int returns a dummy value
 */
int hashmap_create(struct hashmap_s *const out_hashmap)   // Initialize a hashmap
{
  for (int i=0;i<SZ;i++)
  {
    out_hashmap->table[i]=list_new();
    out_hashmap->lk[i]=lock_new();
  }
}

/**
 * @brief This function changes the value of a key to the given value or adds a key with the given value if the key is not already present 
 * 
 * @param hashmap A pointer to the hashmap 
 * @param key The key whose value is to be added/modified
 * @param data The value that is to be associated with the key
 * @return int Retruns a dummy value(-1)
 */
int hashmap_put(struct hashmap_s *const hashmap, const char* key, void* data)   // Set value of the key as data in hashmap. You can use any method to resolve conflicts. Also write your own hashing function

   {  
    char * duuum = (char*)(key);
    int num=hashfunction(duuum,strlen(duuum));
    struct list*  raghav_list= hashmap->table[num];
    struct listentry* raghav_ka_element = raghav_list->head;
    while(raghav_ka_element!=NULL)
    {
      struct hashmap_element_s* hs=(struct hashmap_element_s*)raghav_ka_element->data;
      if((strcmp(hs->key,duuum)))
      {
          raghav_ka_element = raghav_ka_element->next;
      }
      else
      {
        hs->data=data;
        return -1;

      }
    }
    struct hashmap_element_s* newww = (struct hashmap_element_s*)malloc(sizeof(struct hashmap_element_s));
    newww->key=malloc((strlen(duuum)+1)*sizeof(char));
    strcpy(newww->key,key);
    newww->data=data;
    // printf("%s\n\n",newww->key);
    list_add(raghav_list,newww);
    return -1;
}

/**
 * @brief The function fetches the value corresponding to a key
 * 
 * @param hashmap A pointer to the hashmap
 * @param key A pointer to the key whose value is to be accessed
 * @return void* A pointer to the value corresponding to the key. Returns NULL if the key is not present in the hashmap
 */
void* hashmap_get(struct hashmap_s *const hashmap, const char* key)    // Fetch value of a key from hashmap
{

  char * duuum = (char*)(key);
    int num=hashfunction(duuum,strlen(duuum));
    struct list*  raghav_list= hashmap->table[num];
    struct listentry* raghav_ka_element = raghav_list->head;
    while(raghav_ka_element!=NULL)
    {
      struct hashmap_element_s* hs=(struct hashmap_element_s*)raghav_ka_element->data;
      if(strcmp(hs->key,duuum))
      {
          raghav_ka_element = raghav_ka_element->next;
      }
      else
      {
        return hs->data;

      }

    }
    return NULL;

}
/**
 * @brief Execute argument function on each key-value pair in hashmap
 * 
 * @param hashmap The pointer to the hashmap 
 * @param f The function to be executed
 */
void hashmap_iterator(struct hashmap_s* const hashmap, int (*f)(struct hashmap_element_s *const))  // Execute argument function on each key-value pair in hashmap
{
  for(int i =0; i<SZ;i++)
  {
    struct listentry* curr= hashmap->table[i]->head;
    while (curr!=NULL)
    {
        (f)((struct hashmap_element_s*)(curr->data));
        curr=curr->next;
    }
  }
}

/**
 * @brief Set the lock associated with the bucket of the key to the current thread
 * 
 * @param hashmap A pointer to the hashmap
 * @param key A pointer to the key 
 * @return int A dummy return value
 */
int acquire_bucket(struct hashmap_s *const hashmap, const char* key)   // Acquire lock on a hashmap slot
{
  // printf("in acquire bucket\n");
  char * key2 = (char*)(key);
  int bucket = hashfunction(key2,strlen(key2));
  if (hashmap->lk[bucket]->c == NULL){
    // printf("lk->ctx is null\n");
  }
  lock_acquire(hashmap->lk[bucket]);
  return 0;
}
/**
 * @brief Release acquired lock 
 * 
 * @param hashmap A pointer to the hashmap
 * @param key A pointer to the key whose value is to be changed
 * @return int returns a dummy value
 */
int release_bucket(struct hashmap_s *const hashmap, const char* key)   // Release acquired lock
{
  // printf("in release bucket\n");
  char * key2 = (char*)(key);
  int bucket = hashfunction(key2,strlen(key2));
  lock_release(hashmap->lk[bucket]);
  return 0;
}
