#ifndef THREAD_H
#define THREAD_H
#include "../include/list.h"
#include<stdio.h>
#include<stdlib.h>
#include<ucontext.h>
#include<signal.h>
#include<sys/time.h>
#include<unistd.h>

typedef void (* ucfunc_t)(void);
struct list* thread_list;
static ucontext_t* dummy;
static struct listentry* curr;


void mythread_init()     // Initialize threads list
{
    dummy=(ucontext_t*)malloc(sizeof(ucontext_t));
	curr=(struct listentry*)malloc(sizeof(struct listentry));
    thread_list=list_new();
}

ucontext_t* mythread_create(void func(void*), void* arg)  // Create a new thread
{  
    ucontext_t* thread=(ucontext_t*)malloc(sizeof(ucontext_t));
    getcontext(thread);
    char* st1=(char*)malloc(8192*sizeof(char));
    (thread)->uc_stack.ss_sp = st1;
    (thread)->uc_stack.ss_size = 8192;
    (thread)->uc_link = dummy;
    makecontext(thread,(void(*)(void))func,1,arg);
    list_add(thread_list,thread);
	// curr = (struct listentry*)thread_list->head;
    return thread; 
}

void mythread_join()  // Waits for other thread to complete. It is used in case of dependent threads.
{
	if(thread_list->head->data==NULL){
		return;
	}
	while(thread_list->head!=NULL){
		swapcontext(dummy,thread_list->head->data);
		list_rm(thread_list,thread_list->head);
	}
     return;
}

void mythread_yield()  // Perform context switching here
{
	if(thread_list->head==NULL || thread_list->head->next==NULL){
		return;
	}
	else{
		curr->data=thread_list->head->data;
		curr->next=NULL;
		curr->prev=NULL;
		list_add(thread_list,thread_list->head->data);
		list_rm(thread_list,thread_list->head);
		swapcontext((ucontext_t*)(curr->data),(ucontext_t*)(thread_list->head->data));
	}
}

struct lock {
    ucontext_t* ctx;
};

struct lock* lock_new()   // return an initialized lock object
{
	struct lock* lk = (struct lock*)malloc(sizeof(struct lock));
	lk->ctx = NULL ;
	return lk;
}

void lock_acquire(struct lock* lk)   // Set lock. Yield if lock is acquired by some other thread.
{
	while (lk->ctx != NULL){
		mythread_yield();
	}
	lk->ctx = (ucontext_t*)(thread_list->head->data);	
}

int lock_release(struct lock* lk)   // Release lock
{
	lk->ctx = NULL;
}

#endif
