#include "../include/mythread.h"
#include "../include/list.h"
#include <string.h>
#define SZ 4096

struct hashmap_element_s {
  char *key;
  void *data;
};

struct hashmap_s {
  struct list* table[SZ];
  struct lock* lk[SZ];
};

int hashfunction( char string[],int len)
{   
    if (len == 0)
      {
        return 0;
      }
    else return (3023*((int) (string[len-1]))+ hashfunction(string,(len-1)))%4096;// A  completely random hash funciton.
}

int hashmap_create(struct hashmap_s *const out_hashmap)   // Initialize a hashmap
{
  for (int i=0;i<SZ;i++)
  {
    out_hashmap->table[i]=list_new();                    // initializing every table of the hashmap with a linked list
    out_hashmap->lk[i]=lock_new();
  }
}

int hashmap_put(struct hashmap_s *const hashmap, const char* key, void* data)   // Set value of the key as data in hashmap. You can use any method to resolve conflicts. Also write your own hashing function

   {  
    char *key2 = (char*)(key);
    int num = hashfunction(key2,strlen(key2));
    struct list* hashmap_list= hashmap->table[num];
    struct listentry* hash_element = hashmap_list->head;
    while(hash_element!=NULL)
    {
      struct hashmap_element_s* hs=(struct hashmap_element_s*)(hash_element->data);
      if((strcmp(hs->key,key2)))
      {
        hash_element = hash_element->next;
      }
      else
      {
        hs->data=data;
        return -1;
      }
    }
    struct hashmap_element_s* new_element = (struct hashmap_element_s*)malloc(sizeof(struct hashmap_element_s));
    new_element->key=malloc((strlen(key2)+1)*sizeof(char));
    strcpy(new_element->key,key);
    new_element->data=data;
    list_add(hashmap_list,new_element);
    return -1;
}

void* hashmap_get(struct hashmap_s *const hashmap, const char* key)    // Fetch value of a key from hashmap
{

  char *key2 = (char*)(key);
    int num = hashfunction(key2,strlen(key2));
    struct list*  hashmap_list= hashmap->table[num];
    struct listentry* hash_element = hashmap_list->head;
    while(hash_element != NULL)
    {
      struct hashmap_element_s* hs=(struct hashmap_element_s*)hash_element->data;
      if(strcmp(hs->key,key2))
      {
          hash_element = hash_element->next;
      }
      else
      {
        return hs->data;
      }
    }
    return NULL;
}

void hashmap_iterator(struct hashmap_s* const hashmap, int (*f)(struct hashmap_element_s *const))  // Execute argument function on each key-value pair in hashmap
{
  for(int i =0; i<SZ;i++)
  {
    struct listentry* curr= hashmap->table[i]->head;
    while (curr!=NULL)
    {
        (f)((struct hashmap_element_s*)(curr->data));
        curr=curr->next;
    }
  }
}

int acquire_bucket(struct hashmap_s *const hashmap, const char* key)   // Acquire lock on a hashmap slot
{
  char * key2 = (char*)(key);
  int bucket = hashfunction(key2,strlen(key2));
  lock_acquire(hashmap->lk[bucket]);
  return 0;
}

int release_bucket(struct hashmap_s *const hashmap, const char* key)   // Release acquired lock
{
  char * key2 = (char*)(key);
  int bucket = hashfunction(key2,strlen(key2));
  lock_release(hashmap->lk[bucket]);
  return 0;
}
