#ifndef LIST_H
#define LIST_H
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct list {
	struct listentry* head;
	struct listentry* tail;
};

struct listentry {
	void *data;
	struct listentry *prev;
	struct listentry *next;
};

void list_rm(struct list* l, struct listentry* e)    // Remove an item from the list 
{
    if(l->head==l->tail){                            // removal case when there is just one element in the list
        l->head=NULL;
        l->tail=NULL;
        free (e);
        return;
    }
    if (l->head==e){                                 // case when the element to be removed is the head of the list
        l->head=e->next;
        l->head->prev = NULL;
        free (e);
        return;
    }
    if(l->tail==e){                                  // case when the element to be removed is the tail of the list
        l->tail=e->prev;
        l->tail->next = NULL;
        free(e);
        return;
    }
    // in general removal case of element of the list
    e->prev->next=e->next;
    e->next->prev=e->prev;
    free(e);
    return;
}

struct listentry* list_add(struct list* l, void* data)  // Add an item to the list
{  
    if (l->tail==NULL){                                                 // adding an element to list when the list is empty
        struct listentry* item = malloc(sizeof(struct listentry));
        item->prev=NULL;
        item->next=NULL;
        item->data=data;
        l->head=item;
        l->tail=item;
        return item;  
    }else{                                                              // adding an element to the list when it was non-empty initially
        struct listentry* item = malloc(sizeof(struct listentry));
        item->next=NULL;
        item->data=data;
        item->prev=l->tail;
        l->tail->next=item;
        l->tail=item;  
        return item;
    }  
}

struct list* list_new()  // Return an initialized list
{
    struct list* l= malloc(sizeof (struct list));
    l->head=NULL;
    l->tail=NULL;
    return l;

}

int is_empty(struct list* l)  // Check if list is empty or not
{
    if ((l->head) ==NULL) return 1;
    return 0;
}

#endif
